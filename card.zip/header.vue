<template>
  <header
    style="
      background: #0f172a;
      color: #fff;
      padding: 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 2px solid #10b981;
    "
  >
    <div>
      <h1 style="margin: 0; color: #34d399; font-size: 1.5rem">
        Homes & Beyond
      </h1>
      <p style="margin: 0; font-size: 0.75rem; color: #94a3b8">
        Cape Town Short-Term Rentals
      </p>
    </div>
    <div style="display: flex; gap: 0.5rem; font-size: 0.875rem">
      <span
        style="background: #1e293b; padding: 0.5rem 0.75rem; border-radius: 6px"
        >Total: <strong>{{ totalCount }}</strong></span
      >
      <span
        style="
          background: #064e3b;
          color: #34d399;
          padding: 0.5rem 0.75rem;
          border-radius: 6px;
        "
        >Available: <strong>{{ availableCount }}</strong></span
      >
    </div>
  </header>
</template>

<script>
export default {
  props: {
    totalCount: Number,
    availableCount: Number,
  },
};
</script>
