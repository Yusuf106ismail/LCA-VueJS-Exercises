<template>
  <div
    style="
      background: #fff;
      border-radius: 12px;
      border: 1px solid #e2e8f0;
      overflow: hidden;
      position: relative;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    "
  >
    <!-- Availability Badge -->
    <div
      v-if="!property.available"
      style="
        position: absolute;
        top: 12px;
        left: 12px;
        background: #e11d48;
        color: #fff;
        font-size: 0.7rem;
        font-weight: bold;
        padding: 4px 8px;
        border-radius: 4px;
        z-index: 2;
      "
    >
      Not Available
    </div>

    <!-- Bookmark Button -->
    <button
      @click="$emit('toggle-bookmark', property.id)"
      style="
        position: absolute;
        top: 12px;
        right: 12px;
        background: rgba(255, 255, 255, 0.9);
        border: none;
        width: 32px;
        height: 32px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 2;
        font-size: 1.1rem;
      "
    >
      {{ isBookmarked ? "⭐" : "☆" }}
    </button>

    <!-- Image -->
    <div style="height: 180px; background: #f1f5f9; overflow: hidden">
      <img
        :src="property.image"
        :alt="property.title"
        :style="{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          filter: property.available ? 'none' : 'grayscale(100%) opacity(60%)',
        }"
      />
    </div>

    <!-- Details -->
    <div
      style="
        padding: 1rem;
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        gap: 1rem;
      "
    >
      <div>
        <span
          style="
            font-size: 0.75rem;
            color: #64748b;
            text-transform: uppercase;
            font-weight: bold;
          "
          >{{ property.type }} • {{ property.location }}</span
        >
        <h3
          style="
            margin: 0.25rem 0 0 0;
            font-size: 1rem;
            color: #1e293b;
            line-clamp: 2;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            overflow: hidden;
          "
        >
          {{ property.title }}
        </h3>
      </div>

      <div
        style="
          display: flex;
          justify-content: space-between;
          align-items: center;
          border-top: 1px solid #f1f5f9;
          padding-top: 0.75rem;
        "
      >
        <div>
          <span style="font-size: 0.7rem; color: #94a3b8; display: block"
            >Per Night</span
          >
          <span style="font-weight: bold; color: #0f172a"
            >R {{ property.price }}</span
          >
        </div>
        <button
          :disabled="!property.available"
          :style="{
            background: property.available ? '#10b981' : '#cbd5e1',
            color: property.available ? '#fff' : '#94a3b8',
            border: 'none',
            padding: '0.5rem 1rem',
            borderRadius: '6px',
            cursor: property.available ? 'pointer' : 'not-allowed',
            fontWeight: 'bold',
            fontSize: '0.8rem',
          }"
        >
          View Deal
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ["property", "isBookmarked"],
};
</script>
