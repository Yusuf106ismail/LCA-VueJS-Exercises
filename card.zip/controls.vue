<template>
  <div
    style="
      background: #fff;
      padding: 1rem;
      margin: 1.5rem 0;
      border-radius: 12px;
      border: 1px solid #e2e8f0;
      display: flex;
      gap: 1rem;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
    "
  >
    <input
      type="text"
      :value="searchQuery"
      @input="$emit('update:searchQuery', $event.target.value)"
      placeholder="Search by title or neighborhood..."
      style="
        flex: 1;
        min-width: 250px;
        padding: 0.6rem;
        border: 1px solid #cbd5e1;
        border-radius: 8px;
        font-size: 0.9rem;
      "
    />
    <div style="display: flex; align-items: center; gap: 0.5rem">
      <label style="font-size: 0.875rem; color: #475569; font-weight: 500"
        >Sort Price:</label
      >
      <select
        :value="sortBy"
        @change="$emit('update:sortBy', $event.target.value)"
        style="
          padding: 0.6rem;
          border: 1px solid #cbd5e1;
          border-radius: 8px;
          background: #fff;
          font-size: 0.9rem;
        "
      >
        <option value="default">Featured</option>
        <option value="low-high">Low to High</option>
        <option value="high-low">High to Low</option>
      </select>
    </div>
  </div>
</template>

<script>
export default {
  props: ["searchQuery", "sortBy"],
};
</script>
