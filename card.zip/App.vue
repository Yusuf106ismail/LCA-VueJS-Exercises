<template>
  <div
    style="
      min-height: screen;
      background: #f8fafc;
      font-family: system-ui, sans-serif;
      color: #334155;
      padding-bottom: 3rem;
    "
  >
    <AppHeader
      :totalCount="properties.length"
      :availableCount="availableCount"
    />

    <div style="max-width: 1200px; margin: 0 auto; padding: 0 1rem">
      <FilterControls
        v-model:searchQuery="searchQuery"
        v-model:sortBy="sortBy"
      />

      <!-- CSS Grid Component Layout -->
      <div
        v-if="filteredProperties.length > 0"
        style="
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
          gap: 1.5rem;
        "
      >
        <PropertyCard
          v-for="property in filteredProperties"
          :key="property.id"
          :property="property"
          :isBookmarked="bookmarks.includes(property.id)"
          @toggle-bookmark="toggleBookmark"
        />
      </div>

      <!-- Empty State -->
      <div
        v-else
        style="
          text-align: center;
          padding: 3rem;
          background: #fff;
          border-radius: 12px;
          border: 1px solid #e2e8f0;
        "
      >
        <p style="font-size: 1.2rem; color: #64748b; margin: 0">
          No properties found matching your criteria.
        </p>
      </div>
    </div>
  </div>
</template>

<script>
import AppHeader from "./components/AppHeader.vue";
import FilterControls from "./components/FilterControls.vue";
import PropertyCard from "./components/PropertyCard.vue";

export default {
  components: { AppHeader, FilterControls, PropertyCard },
  data() {
    return {
      searchQuery: "",
      sortBy: "default",
      bookmarks: [],
      properties: [
        {
          id: 1,
          title: "Luxury Penthouse Mountain Views",
          location: "City Bowl",
          price: 4500,
          type: "Apartment",
          available: true,
          image:
            "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=400",
        },
        {
          id: 2,
          title: "Modern Beachfront Studio",
          location: "Camps Bay",
          price: 6200,
          type: "Studio",
          available: true,
          image:
            "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=400",
        },
        {
          id: 3,
          title: "Coastal Heritage Cottage",
          location: "Kalk Bay",
          price: 2100,
          type: "Cottage",
          available: false,
          image:
            "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=400",
        },
        {
          id: 4,
          title: "Minimalist Apartment",
          location: "Sea Point",
          price: 1850,
          type: "Apartment",
          available: true,
          image:
            "https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=400",
        },
        {
          id: 5,
          title: "Exclusive Seaboard Villa",
          location: "Clifton",
          price: 12500,
          type: "Villa",
          available: true,
          image:
            "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=400",
        },
        {
          id: 6,
          title: "Industrial Creative Loft",
          location: "Woodstock",
          price: 1500,
          type: "Loft",
          available: false,
          image:
            "https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=400",
        },
      ],
    };
  },
  computed: {
    availableCount() {
      return this.properties.filter((p) => p.available).length;
    },
    filteredProperties() {
      let result = this.properties.filter((p) => {
        const query = this.searchQuery.toLowerCase().trim();
        return (
          p.title.toLowerCase().includes(query) ||
          p.location.toLowerCase().includes(query)
        );
      });
      if (this.sortBy === "low-high") result.sort((a, b) => a.price - b.price);
      if (this.sortBy === "high-low") result.sort((a, b) => b.price - a.price);
      return result;
    },
  },
  methods: {
    toggleBookmark(id) {
      const idx = this.bookmarks.indexOf(id);
      if (idx === -1) this.bookmarks.push(id);
      else this.bookmarks.splice(idx, 1);
      localStorage.setItem("hb_bookmarks", JSON.stringify(this.bookmarks));
    },
  },
  mounted() {
    const saved = localStorage.getItem("hb_bookmarks");
    if (saved) this.bookmarks = JSON.parse(saved);
  },
};
</script>
