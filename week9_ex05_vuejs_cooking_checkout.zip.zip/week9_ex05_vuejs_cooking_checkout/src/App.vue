<template>
  <component :is="'script'" src="https://cdn.tailwindcss.com"></component>

  <div class="min-h-screen bg-slate-50 font-sans antialiased text-slate-800">
    <header class="bg-amber-600 text-white shadow-md sticky top-0 z-50">
      <div
        class="max-w-6xl mx-auto px-4 py-5 sm:px-6 flex justify-between items-center"
      >
        <div>
          <h1 class="text-2xl font-black tracking-tight">
            Cooking Masterclass
          </h1>
          <p class="text-amber-100 text-xs mt-0.5">
            Culinary Experience Checkout Prototype
          </p>
        </div>
        <div
          class="bg-amber-700/50 border border-amber-500/30 px-4 py-2 rounded-xl flex items-center gap-2 text-sm font-semibold"
        >
          🛒
          <span
            >Cart Summary: {{ totalCartItems }}
            {{ totalCartItems === 1 ? "Course" : "Courses" }}</span
          >
        </div>
      </div>
    </header>

    <main
      class="max-w-6xl mx-auto px-4 py-8 sm:px-6 grid grid-cols-1 lg:grid-cols-3 gap-8"
    >
      <section class="lg:col-span-2 space-y-6">
        <h2 class="text-xl font-bold text-slate-900 border-b pb-2">
          Available Culinary Courses
        </h2>

        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
          <div
            v-for="course in courses"
            :key="course.id"
            class="bg-white rounded-2xl shadow-sm border border-slate-100 p-5 flex flex-col justify-between hover:shadow-md transition duration-150 relative overflow-hidden"
          >
            <div
              v-if="course.isSoldOut"
              class="absolute top-3 right-3 bg-red-500 text-white text-[10px] font-black uppercase px-2.5 py-1 rounded-md tracking-wider shadow-sm z-10"
            >
              Sold Out
            </div>

            <div>
              <span
                class="inline-block text-[10px] font-bold uppercase tracking-wider text-amber-600 bg-amber-50 px-2 py-0.5 rounded mb-2"
              >
                {{ course.difficulty }}
              </span>
              <h3 class="text-base font-bold text-slate-900 capitalize mb-1">
                {{ course.title }}
              </h3>
              <p class="text-xs text-slate-500 mb-4 line-clamp-2">
                {{ course.description }}
              </p>

              <div
                class="space-y-1.5 text-xs text-slate-600 mb-4 bg-slate-50 p-2.5 rounded-xl"
              >
                <p>
                  👨‍🍳 <span class="font-medium text-slate-700">Chef:</span>
                  {{ course.chef }}
                </p>
                <p>
                  ⏱️ <span class="font-medium text-slate-700">Duration:</span>
                  {{ course.duration }}
                </p>
              </div>
            </div>

            <div
              class="pt-3 border-t border-slate-100 flex items-center justify-between mt-auto"
            >
              <span class="text-lg font-black text-slate-900"
                >R {{ course.price.toFixed(2) }}</span
              >

              <button
                @click="addToCart(course)"
                :disabled="course.isSoldOut"
                class="px-4 py-2 rounded-xl text-xs font-bold transition duration-150"
                :class="
                  course.isSoldOut
                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    : 'bg-amber-600 hover:bg-amber-700 text-white shadow-sm active:bg-amber-800'
                "
              >
                {{ course.isSoldOut ? "Unavailable" : "Add to Cart" }}
              </button>
            </div>
          </div>
        </div>
      </section>

      <section class="lg:col-span-1">
        <div
          class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 sticky top-24 space-y-6"
        >
          <div class="flex items-center justify-between border-b pb-3">
            <h2 class="text-lg font-bold text-slate-900">Selected Cart</h2>
            <button
              v-if="cart.length > 0"
              @click="clearCart"
              class="text-xs font-semibold text-red-500 hover:text-red-700 transition"
            >
              Clear All
            </button>
          </div>

          <div v-if="cart.length === 0" class="py-12 text-center">
            <span class="text-3xl block mb-2">🛒</span>
            <p class="text-sm font-semibold text-slate-700">
              Your basket is currently empty
            </p>
            <p class="text-xs text-slate-400 mt-1 max-w-[200px] mx-auto">
              Select a masterclass course from the menu list to start.
            </p>
          </div>

          <div v-else class="space-y-4 max-h-[280px] overflow-y-auto pr-1">
            <div
              v-for="item in cart"
              :key="item.id"
              class="flex items-start justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs"
            >
              <div class="flex-1 min-w-0">
                <h4 class="font-bold text-slate-900 truncate">
                  {{ item.title }}
                </h4>
                <p class="text-slate-500 text-[11px] mt-0.5">
                  R {{ item.price.toFixed(2) }} each
                </p>
                <p class="text-amber-600 font-semibold text-[11px] mt-1">
                  Subtotal: R {{ (item.price * item.quantity).toFixed(2) }}
                </p>
              </div>

              <div class="flex flex-col items-end gap-2 shrink-0">
                <div
                  class="flex items-center border bg-white rounded-lg overflow-hidden"
                >
                  <button
                    @click="updateQuantity(item.id, -1)"
                    class="px-2 py-1 hover:bg-slate-100 text-slate-600 font-bold transition"
                  >
                    -
                  </button>
                  <span
                    class="px-2 font-semibold text-slate-800 text-center min-w-[24px]"
                    >{{ item.quantity }}</span
                  >
                  <button
                    @click="updateQuantity(item.id, 1)"
                    class="px-2 py-1 hover:bg-slate-100 text-slate-600 font-bold transition"
                  >
                    +
                  </button>
                </div>
                <button
                  @click="removeFromCart(item.id)"
                  class="text-[10px] font-medium text-red-500 hover:underline"
                >
                  Remove
                </button>
              </div>
            </div>
          </div>

          <div v-if="cart.length > 0" class="pt-4 border-t border-slate-100">
            <label
              class="block text-[11px] font-bold text-slate-600 uppercase tracking-wider mb-1.5"
              >Have a Promo Coupon Code?</label
            >
            <div class="flex gap-2">
              <input
                v-model="couponInput"
                type="text"
                placeholder="Try: SAVE10"
                class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs uppercase focus:outline-none focus:border-amber-500 placeholder:text-slate-400"
                :disabled="isCouponApplied"
              />
              <button
                @click="applyCoupon"
                :disabled="isCouponApplied"
                class="px-3 py-2 text-xs font-bold rounded-xl transition"
                :class="
                  isCouponApplied
                    ? 'bg-emerald-100 text-emerald-700'
                    : 'bg-slate-800 hover:bg-slate-900 text-white'
                "
              >
                {{ isCouponApplied ? "Applied" : "Apply" }}
              </button>
            </div>
            <p
              v-if="couponError"
              class="text-red-500 text-[11px] font-medium mt-1"
            >
              ❌ {{ couponError }}
            </p>
            <p
              v-if="isCouponApplied"
              class="text-emerald-600 text-[11px] font-semibold mt-1"
            >
              🎉 10% Coupon discount activated successfully!
            </p>
          </div>

          <div
            v-if="cart.length > 0"
            class="pt-4 border-t border-slate-100 space-y-2.5 text-xs"
          >
            <div class="flex justify-between text-slate-600">
              <span>Subtotal Balance</span>
              <span>R {{ subtotal.toFixed(2) }}</span>
            </div>
            <div
              v-if="discountAmount > 0"
              class="flex justify-between text-emerald-600 font-medium"
            >
              <span>Coupon Discount (10%)</span>
              <span>- R {{ discountAmount.toFixed(2) }}</span>
            </div>
            <div class="flex justify-between text-slate-600">
              <span>Estimated Tax (15% VAT)</span>
              <span>R {{ taxTotal.toFixed(2) }}</span>
            </div>
            <div
              class="pt-3 border-t border-slate-200 flex justify-between text-slate-900 font-black text-base"
            >
              <span>Grand Total</span>
              <span class="text-amber-600">R {{ grandTotal.toFixed(2) }}</span>
            </div>

            <button
              @click="simulateCheckout"
              class="w-full bg-amber-600 hover:bg-amber-700 text-white font-bold py-3 px-4 rounded-xl transition duration-150 text-sm mt-2 shadow-sm"
            >
              Proceed to Simulation Checkout
            </button>
          </div>
        </div>
      </section>
    </main>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from "vue";

// --- IN-MEMORY BASELINE STATIC DATASET: THE CATALOGUE ---
const courses = ref([
  {
    id: 101,
    title: "Art of Artisan Pastry & Croissants",
    chef: "Chef Jean-Luc",
    description:
      "Master the secrets of lamination, folding techniques, and achieving flawless honeycomb internal crumbs.",
    price: 1250.0,
    duration: "4 Hours",
    difficulty: "Advanced",
    isSoldOut: false,
  },
  {
    id: 102,
    title: "Gourmet Italian Hand-Rolled Pasta",
    chef: "Chef Francesca",
    description:
      "Craft classic egg-yolk semolina doughs and execute exquisite regional rich reduction fillings.",
    price: 890.0,
    duration: "3 Hours",
    difficulty: "Beginner",
    isSoldOut: false,
  },
  {
    id: 103,
    title: "Precision Japanese Sushi Architecture",
    chef: "Chef Kenji",
    description:
      "Perfect local sushi rice acidification seasoning, knife honing refinement, and high-tier fish slice slicing.",
    price: 1600.0,
    duration: "5 Hours",
    difficulty: "Intermediate",
    isSoldOut: true, // Requirement Test Hook: SOLD OUT
  },
  {
    id: 104,
    title: "Mastering Fire, Wood smoke & Braai",
    chef: "Chef Thabo",
    description:
      "Deep dive into temperature zoning control, customized dry seasoning rubs, and high-heat protein reverse searing.",
    price: 950.0,
    duration: "3.5 Hours",
    difficulty: "Intermediate",
    isSoldOut: false,
  },
]);

// --- SYSTEM STATE MANAGEMENT VARIABLES ---
const cart = ref([]);
const couponInput = ref("");
const isCouponApplied = ref(false);
const couponError = ref("");

// --- LIFECYCLE HOOKS & PERSISTENCE ---
onMounted(() => {
  const cachedBasket = localStorage.getItem("masterclass_cart");
  const cachedCouponStatus = localStorage.getItem("masterclass_coupon_status");

  if (cachedBasket) {
    try {
      cart.value = JSON.parse(cachedBasket);
    } catch (e) {
      localStorage.removeItem("masterclass_cart");
    }
  }
  if (cachedCouponStatus === "true") {
    isCouponApplied.value = true;
    couponInput.value = "SAVE10";
  }
});

// Watch tracking mutations deep to secure cache integrity
watch(
  cart,
  (newBasketState) => {
    localStorage.setItem("masterclass_cart", JSON.stringify(newBasketState));
  },
  { deep: true },
);

watch(isCouponApplied, (newCouponState) => {
  localStorage.setItem("masterclass_coupon_status", newCouponState.toString());
});

// --- COMPUTED PROPERTIES MATH MATRIX (Objective 3 / Success Criteria 3) ---
const totalCartItems = computed(() => {
  return cart.value.reduce(
    (accumulator, item) => accumulator + item.quantity,
    0,
  );
});

const subtotal = computed(() => {
  return cart.value.reduce(
    (accumulator, item) => accumulator + item.price * item.quantity,
    0,
  );
});

const discountAmount = computed(() => {
  if (!isCouponApplied.value) return 0;
  return subtotal.value * 0.1; // Deduct exactly 10% off items
});

const taxTotal = computed(() => {
  // Simple tax calculation (15% VAT modeled out from baseline post-discount price)
  const taxableBasis = subtotal.value - discountAmount.value;
  return taxableBasis * 0.15;
});

const grandTotal = computed(() => {
  return subtotal.value - discountAmount.value + taxTotal.value;
});

// --- CORE ACTION METHOD INTELLIGENCE RULES ---
const addToCart = (selectedCourse) => {
  if (selectedCourse.isSoldOut) return;

  // Check if target element matches any currently stored index tracker
  const existingItem = cart.value.find((item) => item.id === selectedCourse.id);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.value.push({
      id: selectedCourse.id,
      title: selectedCourse.title,
      price: selectedCourse.price,
      quantity: 1,
    });
  }
};

const updateQuantity = (itemID, directionalOffset) => {
  const matchingItem = cart.value.find((item) => item.id === itemID);
  if (!matchingItem) return;

  matchingItem.quantity += directionalOffset;

  // Cleanup check: drop item if decrement action falls lower than 1 unit
  if (matchingItem.quantity <= 0) {
    removeFromCart(itemID);
  }
};

const removeFromCart = (itemID) => {
  cart.value = cart.value.filter((item) => item.id !== itemID);
};

const clearCart = () => {
  cart.value = [];
  isCouponApplied.value = false;
  couponInput.value = "";
  couponError.value = "";
};

const applyCoupon = () => {
  couponError.value = "";
  if (couponInput.value.trim().toUpperCase() === "SAVE10") {
    isCouponApplied.value = true;
  } else {
    couponError.value = "Invalid discount credential code. Try using: SAVE10";
  }
};

const simulateCheckout = () => {
  alert(
    `🛒 [Simulation Success Mode]\n\nProcessing order sequence tracking for a net amount total of R ${grandTotal.value.toFixed(2)} (VAT Inc.)!\n\nThank you for choosing Cooking Masterclass.`,
  );
  clearCart();
};
</script>
