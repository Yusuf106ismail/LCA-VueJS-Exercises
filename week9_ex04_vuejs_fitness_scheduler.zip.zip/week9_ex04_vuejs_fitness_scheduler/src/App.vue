<template>
  <component :is="'script'" src="https://cdn.tailwindcss.com"></component>

  <div class="min-h-screen bg-slate-50 font-sans antialiased text-slate-800">
    <header class="bg-indigo-600 text-white shadow-md">
      <div
        class="max-w-6xl mx-auto px-4 py-6 sm:px-6 flex flex-col md:flex-row justify-between items-center gap-6"
      >
        <div>
          <h1 class="text-3xl font-extrabold tracking-tight">
            FlexZone Fitness
          </h1>
          <p class="text-indigo-200 text-sm mt-1">
            Instructor & Class Schedule Management Portal
          </p>
        </div>

        <div class="flex flex-wrap gap-4 items-stretch justify-center">
          <div
            class="bg-indigo-700/60 backdrop-blur-sm border border-indigo-500/30 px-5 py-3 rounded-xl min-w-[120px] text-center"
          >
            <span class="block text-3xl font-bold tracking-tight">{{
              totalSessions
            }}</span>
            <span
              class="text-[11px] text-indigo-200 font-medium uppercase tracking-wider"
              >Total Classes</span
            >
          </div>

          <div
            v-if="nextSession"
            class="bg-indigo-700/60 backdrop-blur-sm border border-indigo-500/30 px-5 py-3 rounded-xl max-w-xs"
          >
            <span
              class="text-[11px] text-indigo-200 font-medium uppercase tracking-wider block mb-0.5"
              >Next Session</span
            >
            <span class="block text-sm font-bold truncate text-white">{{
              nextSession.className
            }}</span>
            <span class="block text-xs text-indigo-200 mt-0.5">
              📅 {{ formatDate(nextSession.classDate) }} at
              {{ nextSession.classTime }}
            </span>
          </div>
        </div>
      </div>
    </header>

    <main
      class="max-w-6xl mx-auto px-4 py-8 sm:px-6 grid grid-cols-1 lg:grid-cols-3 gap-8"
    >
      <section class="lg:col-span-1">
        <div
          class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 sticky top-6"
        >
          <h2 class="text-xl font-bold text-slate-900 mb-1">
            Schedule New Session
          </h2>
          <p class="text-xs text-slate-500 mb-5">
            Fill in all fields to add a session to the board.
          </p>

          <form @submit.prevent="handleSubmit" class="space-y-4">
            <div>
              <label
                class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1"
                >Class Name</label
              >
              <input
                v-model.trim="form.className"
                type="text"
                placeholder="e.g., Pilates Core, HIIT Circuit"
                class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition placeholder:text-slate-400 text-sm"
                :class="{
                  'border-red-400 focus:border-red-500 focus:ring-red-500/10':
                    errors.className,
                }"
              />
              <p
                v-if="errors.className"
                class="text-red-500 text-xs font-medium mt-1.5 flex items-center gap-1"
              >
                ⚠️ {{ errors.className }}
              </p>
            </div>

            <div>
              <label
                class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1"
                >Instructor / Coach</label
              >
              <input
                v-model.trim="form.coachName"
                type="text"
                placeholder="e.g., Coach Sarah"
                class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition placeholder:text-slate-400 text-sm"
                :class="{
                  'border-red-400 focus:border-red-500 focus:ring-red-500/10':
                    errors.coachName,
                }"
              />
              <p
                v-if="errors.coachName"
                class="text-red-500 text-xs font-medium mt-1.5 flex items-center gap-1"
              >
                ⚠️ {{ errors.coachName }}
              </p>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label
                  class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1"
                  >Date</label
                >
                <input
                  v-model="form.classDate"
                  type="date"
                  class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition text-sm"
                  :class="{
                    'border-red-400 focus:border-red-500 focus:ring-red-500/10':
                      errors.classDate,
                  }"
                />
                <p
                  v-if="errors.classDate"
                  class="text-red-500 text-xs font-medium mt-1.5"
                >
                  ⚠️ {{ errors.classDate }}
                </p>
              </div>
              <div>
                <label
                  class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1"
                  >Start Time</label
                >
                <input
                  v-model="form.classTime"
                  type="time"
                  class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition text-sm"
                  :class="{
                    'border-red-400 focus:border-red-500 focus:ring-red-500/10':
                      errors.classTime,
                  }"
                />
                <p
                  v-if="errors.classTime"
                  class="text-red-500 text-xs font-medium mt-1.5"
                >
                  ⚠️ {{ errors.classTime }}
                </p>
              </div>
            </div>

            <div>
              <label
                class="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1"
                >Maximum Capacity</label
              >
              <input
                v-model.number="form.capacity"
                type="number"
                min="1"
                placeholder="e.g., 25"
                class="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition placeholder:text-slate-400 text-sm"
                :class="{
                  'border-red-400 focus:border-red-500 focus:ring-red-500/10':
                    errors.capacity,
                }"
              />
              <p
                v-if="errors.capacity"
                class="text-red-500 text-xs font-medium mt-1.5 flex items-center gap-1"
              >
                ⚠️ {{ errors.capacity }}
              </p>
            </div>

            <button
              type="submit"
              class="w-full bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-semibold py-3 px-4 rounded-xl transition duration-150 text-sm shadow-sm hover:shadow-md mt-2"
            >
              Add Session to Schedule
            </button>
          </form>
        </div>
      </section>

      <section class="lg:col-span-2 space-y-4">
        <div
          class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl shadow-sm border border-slate-100"
        >
          <h2 class="text-lg font-bold text-slate-900">
            Current Sessions Queue
          </h2>

          <div class="relative min-w-[240px]">
            <input
              v-model="searchQuery"
              type="text"
              placeholder="🔍 Filter schedules by coach..."
              class="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition"
            />
          </div>
        </div>

        <div
          v-if="filteredSessions.length === 0"
          class="bg-white rounded-2xl p-16 text-center shadow-sm border border-dashed border-slate-200"
        >
          <div
            class="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl text-slate-400"
          >
            📋
          </div>
          <h3 class="text-base font-semibold text-slate-800 mb-1">
            No active fitness sessions scheduled
          </h3>
          <p class="text-xs text-slate-400 max-w-xs mx-auto">
            The schedule is currently empty. Use the form to submit a new
            workout session.
          </p>
        </div>

        <div v-else class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div
            v-for="session in filteredSessions"
            :key="session.id"
            class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex flex-col justify-between hover:shadow-md hover:border-slate-200 transition duration-150 group"
          >
            <div>
              <div class="flex items-start justify-between gap-2 mb-3">
                <h3
                  class="text-base font-bold text-slate-900 group-hover:text-indigo-600 transition truncate capitalize"
                >
                  {{ session.className }}
                </h3>
                <span
                  class="inline-flex items-center bg-slate-100 text-slate-700 text-[10px] font-bold px-2.5 py-1 rounded-md whitespace-nowrap"
                >
                  Max: {{ session.capacity }}
                </span>
              </div>

              <div class="space-y-2 text-xs text-slate-600">
                <p class="flex items-center gap-1.5">
                  <span class="text-slate-400 font-medium">Instructor:</span>
                  <span class="font-semibold text-slate-800 capitalize">{{
                    session.coachName
                  }}</span>
                </p>
                <div
                  class="pt-3 border-t border-slate-50 flex items-center justify-between text-[11px] text-slate-500"
                >
                  <span class="flex items-center gap-1"
                    >📅 {{ formatDate(session.classDate) }}</span
                  >
                  <span
                    class="flex items-center gap-1 font-medium text-slate-700"
                    >⏰ {{ session.classTime }}</span
                  >
                </div>
              </div>
            </div>

            <button
              @click="deleteSession(session.id)"
              class="mt-5 w-full text-center text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 active:bg-red-200 py-2.5 rounded-xl transition duration-150"
            >
              Cancel Class Session
            </button>
          </div>
        </div>
      </section>
    </main>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, watch } from "vue";

// --- Reactive State ---
const sessions = ref([]);
const searchQuery = ref("");

// Form Bindings
const form = reactive({
  className: "",
  coachName: "",
  classDate: "",
  classTime: "",
  capacity: null,
});

// Error States
const errors = reactive({
  className: "",
  coachName: "",
  classDate: "",
  classTime: "",
  capacity: "",
});

// --- LocalStorage Persistence (Stretch Goal 1) ---
onMounted(() => {
  const activeCache = localStorage.getItem("flexzone_schedules");
  if (activeCache) {
    try {
      sessions.value = JSON.parse(activeCache);
    } catch (e) {
      localStorage.removeItem("flexzone_schedules");
    }
  }
});

watch(
  sessions,
  (updatedList) => {
    localStorage.setItem("flexzone_schedules", JSON.stringify(updatedList));
  },
  { deep: true },
);

// --- Computed Properties ---
// 1. Total Count (Key Feature 5)
const totalSessions = computed(() => sessions.value.length);

// 2. Filter Lists (Stretch Goal 3)
const filteredSessions = computed(() => {
  const query = searchQuery.value.trim().toLowerCase();
  if (!query) return sessions.value;
  return sessions.value.filter((item) =>
    item.coachName.toLowerCase().includes(query),
  );
});

// 3. Find Next Upcoming Session Chronologically (Stretch Goal 2)
const nextSession = computed(() => {
  if (sessions.value.length === 0) return null;

  const operationalClone = [...sessions.value];
  operationalClone.sort((alpha, beta) => {
    const timestampAlpha = new Date(
      `${alpha.classDate.replace(/-/g, "/")} ${alpha.classTime}`,
    );
    const timestampBeta = new Date(
      `${beta.classDate.replace(/-/g, "/")} ${beta.classTime}`,
    );
    return timestampAlpha - timestampBeta;
  });

  return operationalClone[0];
});

// --- Methods & Logic ---
// Form Inputs Validation Routine (Objective 3)
const isFormValid = () => {
  let integrityMarker = true;

  Object.keys(errors).forEach((field) => (errors[field] = ""));

  if (!form.className.trim()) {
    errors.className = "A descriptive class title is required.";
    integrityMarker = false;
  }
  if (!form.coachName.trim()) {
    errors.coachName = "Instructor name assignment is required.";
    integrityMarker = false;
  }
  if (!form.classDate) {
    errors.classDate = "Date coordinates required.";
    integrityMarker = false;
  }
  if (!form.classTime) {
    errors.classTime = "Target start time required.";
    integrityMarker = false;
  }
  if (!form.capacity || Number(form.capacity) <= 0) {
    errors.capacity = "Capacity threshold value must exceed 0.";
    integrityMarker = false;
  }

  return integrityMarker;
};

// Form Submission (Key Feature 1 & 2)
const handleSubmit = () => {
  if (!isFormValid()) return;

  sessions.value.push({
    id: Date.now() + Math.random(),
    className: form.className.trim(),
    coachName: form.coachName.trim(),
    classDate: form.classDate,
    classTime: form.classTime,
    capacity: parseInt(form.capacity, 10),
  });

  // Reset form inputs completely
  form.className = "";
  form.coachName = "";
  form.classDate = "";
  form.classTime = "";
  form.capacity = null;
};

// Delete Action Method (Key Feature 3)
const deleteSession = (targetID) => {
  sessions.value = sessions.value.filter((item) => item.id !== targetID);
};

// Date Formatter Helper Utility
const formatDate = (rawDateStr) => {
  if (!rawDateStr) return "";
  const structuredDate = new Date(rawDateStr.replace(/-/g, "/"));
  return structuredDate.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
};
</script>
