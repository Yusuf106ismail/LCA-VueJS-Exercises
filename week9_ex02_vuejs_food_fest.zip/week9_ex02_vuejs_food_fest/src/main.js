const { createApp, ref, computed, h, Transition } = Vue

const ticketData = [
  {
    id: 1,
    tier: 'Bronze',
    price: 250,
    description: 'Your entry into a weekend of incredible flavour.',
    featured: false,
    benefits: [
      'General admission - both days',
      'Access to all food stalls',
      'Live music on the main stage',
      'Festival map and programme',
    ],
  },
  {
    id: 2,
    tier: 'Silver',
    price: 490,
    description: 'The complete Food Fest experience, start to finish.',
    featured: true,
    benefits: [
      'Everything in Bronze',
      'Priority entry - skip the queue',
      '1 complimentary tasting paddle',
      'Access to chef demo tent',
      'Festival tote bag',
    ],
  },
  {
    id: 3,
    tier: 'Gold',
    price: 890,
    description: 'Full VIP treatment - because you deserve it.',
    featured: false,
    benefits: [
      'Everything in Silver',
      'VIP lounge access all weekend',
      '3-course Saturday evening dinner',
      'Meet and greet with featured chefs',
      'Exclusive Gold gift box',
    ],
  },
]

const TicketCard = {
  props: {
    ticket: { type: Object, required: true },
    isDark: { type: Boolean, default: true },
  },
  emits: ['favourite-toggled'],
  setup(props, { emit, slots }) {
    const favourited = ref(false)
    function toggleFavourite() {
      favourited.value = !favourited.value
      emit('favourite-toggled', { id: props.ticket.id, favourited: favourited.value })
    }

    return () => {
      const t = props.ticket
      const classes = ['card']
      if (t.featured) classes.push('card--featured')

      const heartSvg = h('svg', { viewBox: '0 0 24 24', width: 20, height: 20, fill: 'currentColor', 'aria-hidden': 'true' },
        h('path', { d: 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z' })
      )

      const favBtn = h('button', {
        class: favourited.value ? 'card__fav card__fav--active' : 'card__fav',
        onClick: toggleFavourite,
        'aria-pressed': favourited.value,
        'aria-label': favourited.value ? 'Remove from favourites' : 'Save to favourites',
      }, heartSvg)

      const badge = slots.badge ? slots.badge() : h('div', { class: 'card__badge-placeholder' })

      const benefitItems = t.benefits.map((b, i) =>
        h('li', { key: i, class: 'card__benefit' }, [
          h('span', { class: 'card__check', 'aria-hidden': 'true' }, 'v'),
          h('span', b),
        ])
      )

      const ctaSlot = slots.cta ? slots.cta() : h('button', { class: 'card__cta' }, 'Notify Me')

      return h('article', { class: classes.join(' ') }, [
        badge,
        h('div', { class: 'card__inner' }, [
          h('div', { class: 'card__top' }, [
            h('h3', { class: 'card__tier' }, t.tier),
            favBtn,
          ]),
          h('div', { class: 'card__price' }, [
            h('span', { class: 'card__currency' }, 'R'),
            h('span', { class: 'card__amount' }, t.price),
            h('span', { class: 'card__per' }, 'per person'),
          ]),
          h('p', { class: 'card__description' }, t.description),
          h('ul', { class: 'card__benefits' }, benefitItems),
          ctaSlot,
        ]),
      ])
    }
  },
}

const App = {
  components: { TicketCard },
  setup() {
    const isDark = ref(true)
    function toggleMode() { isDark.value = !isDark.value }

    const sortBy = ref('default')
    const sortOptions = [
      { value: 'default',    label: 'Default'    },
      { value: 'price-asc',  label: 'Price up'   },
      { value: 'price-desc', label: 'Price down' },
    ]

    const sortedTickets = computed(() => {
      const list = [...ticketData]
      if (sortBy.value === 'price-asc')  return list.sort((a, b) => a.price - b.price)
      if (sortBy.value === 'price-desc') return list.sort((a, b) => b.price - a.price)
      return list
    })

    const favouriteIds = ref(new Set())
    const favouriteCount = computed(() => favouriteIds.value.size)

    function handleFavouriteToggled({ id, favourited }) {
      const next = new Set(favouriteIds.value)
      favourited ? next.add(id) : next.delete(id)
      favouriteIds.value = next
      showToast(favourited ? 'Saved to favourites' : 'Removed from favourites')
    }

    const toastMsg = ref('')
    const toastVisible = ref(false)
    let toastTimer = null
    function showToast(msg) {
      toastMsg.value = msg
      toastVisible.value = true
      clearTimeout(toastTimer)
      toastTimer = setTimeout(() => { toastVisible.value = false }, 2000)
    }

    return () => {
      const themeClass = isDark.value ? 'app theme--dark' : 'app theme--light'

      const eyebrow = h('span', { class: 'header__eyebrow' }, 'Cape Town - Green Point Park')
      const title   = h('h1', { class: 'header__title' }, [
        'Cape Town',
        h('br'),
        h('em', 'Food Fest'),
      ])
      const dates = h('p', { class: 'header__dates' }, '14 - 16 November 2025')
      const sub   = h('p', { class: 'header__sub' }, 'Three days of street food, world-class chefs, and live music on the Atlantic seaboard.')
      const modeBtn = h('button', { class: 'mode-toggle', onClick: toggleMode }, isDark.value ? 'Light mode' : 'Dark mode')

      const header = h('header', { class: 'header' }, [
        h('div', { class: 'header__inner' }, [eyebrow, title, dates, sub]),
        modeBtn,
      ])

      const heading = h('h2', { class: 'main__heading' }, 'Choose your ticket')
      const savedMsg = favouriteCount.value > 0
        ? h('p', { class: 'main__saved', 'aria-live': 'polite' }, favouriteCount.value + (favouriteCount.value === 1 ? ' tier saved' : ' tiers saved'))
        : null

      const sortBtns = sortOptions.map(opt =>
        h('button', {
          key: opt.value,
          class: sortBy.value === opt.value ? 'sort-btn sort-btn--active' : 'sort-btn',
          onClick: () => { sortBy.value = opt.value },
        }, opt.label)
      )

      const controls = h('div', { class: 'main__controls' }, [
        h('div', { class: 'main__controls-left' }, [heading, savedMsg]),
        h('div', { class: 'sort-group', role: 'group', 'aria-label': 'Sort tickets' }, sortBtns),
      ])

      const cards = sortedTickets.value.map(ticket =>
        h(TicketCard, {
          key: ticket.id,
          ticket,
          isDark: isDark.value,
          onFavouriteToggled: handleFavouriteToggled,
        }, {
          badge: ticket.featured ? () => h('div', { class: 'featured-badge' }, 'Most Popular') : undefined,
          cta: () => h('button', { class: 'card__cta' }, ticket.featured ? 'Buy Now' : 'Notify Me'),
        })
      )

      const grid = h('div', { class: 'grid' }, cards)

      const main = h('main', { class: 'main' }, [controls, grid])

      const footer = h('footer', { class: 'footer' },
        h('p', '2025 Cape Town Food Fest - All prices include VAT - Tickets non-refundable')
      )

      const toast = h(Transition, { name: 'toast' },
        () => toastVisible.value ? h('div', { class: 'toast', role: 'status', 'aria-live': 'polite' }, toastMsg.value) : null
      )

      return h('div', { class: themeClass }, [header, main, footer, toast])
    }
  },
}

const css = `
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body { font-family: Inter, sans-serif; font-size: 16px; line-height: 1.6; -webkit-font-smoothing: antialiased; }

.theme--dark  { --bg: #0f1a24; --surface: #1c2d3e; --border: #263d52; --text: #f0ede6; --text2: #8fa3b3; --accent: #e8a020; --accent2: #bf6b1a; --featured-bg: #1a2a14; --featured-border: #e8a020; }
.theme--light { --bg: #faf7f2; --surface: #ffffff; --border: #ddd6c8; --text: #1a1410; --text2: #6b5e52; --accent: #c47a15; --accent2: #9a5c0a; --featured-bg: #fffbef; --featured-border: #c47a15; }

.app { min-height: 100vh; display: flex; flex-direction: column; background: var(--bg); color: var(--text); transition: background 0.3s, color 0.3s; }

.header { position: relative; padding: 60px 24px 52px; text-align: center; background: var(--bg); border-bottom: 1px solid var(--border); }
.header__eyebrow { display: block; font-size: 0.72rem; font-weight: 600; letter-spacing: 0.22em; text-transform: uppercase; color: var(--accent); margin-bottom: 20px; }
.header__title { font-family: Playfair Display, serif; font-size: clamp(3rem, 9vw, 6.5rem); font-weight: 900; line-height: 1; letter-spacing: -0.02em; color: var(--text); margin-bottom: 14px; }
.header__title em { color: var(--accent); font-style: italic; }
.header__dates { font-size: 0.9rem; font-weight: 300; color: var(--text2); letter-spacing: 0.06em; margin-bottom: 16px; }
.header__sub { max-width: 440px; margin: 0 auto; font-size: 0.9rem; color: var(--text2); font-weight: 300; line-height: 1.7; }

.mode-toggle { position: absolute; top: 20px; right: 20px; background: var(--surface); border: 1px solid var(--border); color: var(--text2); font-family: Inter, sans-serif; font-size: 0.78rem; font-weight: 500; padding: 6px 14px; border-radius: 100px; cursor: pointer; transition: background 0.2s, color 0.2s; }
.mode-toggle:hover { color: var(--text); border-color: var(--text2); }

.main { flex: 1; padding: 48px 24px 64px; max-width: 1080px; width: 100%; margin: 0 auto; }
.main__controls { display: flex; align-items: flex-end; justify-content: space-between; flex-wrap: wrap; gap: 16px; margin-bottom: 32px; }
.main__heading { font-family: Playfair Display, serif; font-size: 1.8rem; font-weight: 700; color: var(--text); }
.main__saved { font-size: 0.8rem; color: #e05c6e; margin-top: 4px; }

.sort-group { display: flex; gap: 8px; }
.sort-btn { background: transparent; border: 1px solid var(--border); color: var(--text2); font-family: Inter, sans-serif; font-size: 0.78rem; padding: 6px 14px; border-radius: 100px; cursor: pointer; transition: background 0.15s, color 0.15s, border-color 0.15s; }
.sort-btn:hover { border-color: var(--text2); color: var(--text); }
.sort-btn--active { background: var(--accent); border-color: var(--accent); color: #fff; font-weight: 600; }

.grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }

.card { border-radius: 14px; overflow: hidden; border: 1px solid var(--border); background: var(--surface); transition: transform 0.22s ease, box-shadow 0.22s ease; display: flex; flex-direction: column; }
.card:hover { transform: translateY(-5px); box-shadow: 0 18px 48px rgba(0,0,0,0.25); }
.card--featured { border-color: var(--featured-border); background: var(--featured-bg); box-shadow: 0 0 0 1px var(--featured-border), 0 6px 28px rgba(232,160,32,0.15); }

.card__badge-placeholder { height: 0; }
.featured-badge { background: var(--accent); color: #fff; font-size: 0.7rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; text-align: center; padding: 7px 16px; }

.card__inner { padding: 24px 22px 22px; display: flex; flex-direction: column; gap: 14px; flex: 1; }
.card__top { display: flex; align-items: center; justify-content: space-between; }
.card__tier { font-family: Playfair Display, serif; font-size: 1.5rem; font-weight: 700; color: var(--text); }
.card--featured .card__tier { color: var(--accent); }

.card__fav { background: none; border: none; cursor: pointer; padding: 4px; color: var(--border); transition: color 0.18s, transform 0.18s; display: flex; align-items: center; }
.card__fav:hover { color: #e05c6e; transform: scale(1.18); }
.card__fav--active { color: #e05c6e; animation: heartPop 0.26s ease; }
@keyframes heartPop { 0%{transform:scale(1)} 50%{transform:scale(1.35)} 100%{transform:scale(1)} }

.card__price { display: flex; align-items: baseline; gap: 3px; }
.card__currency { font-size: 1rem; font-weight: 600; color: var(--text2); }
.card__amount { font-family: Playfair Display, serif; font-size: 2.8rem; font-weight: 900; line-height: 1; color: var(--text); }
.card--featured .card__amount { color: var(--accent); }
.card__per { font-size: 0.78rem; color: var(--text2); margin-left: 6px; }
.card__description { font-size: 0.85rem; color: var(--text2); font-weight: 300; line-height: 1.6; font-style: italic; }

.card__benefits { list-style: none; display: flex; flex-direction: column; gap: 9px; flex: 1; }
.card__benefit { display: flex; align-items: flex-start; gap: 10px; font-size: 0.855rem; color: var(--text2); line-height: 1.45; }
.card__check { color: var(--accent); font-weight: 900; flex-shrink: 0; font-size: 0.75rem; margin-top: 3px; }

.card__cta { margin-top: 6px; padding: 11px 20px; border-radius: 8px; border: 1.5px solid var(--border); background: transparent; color: var(--text2); font-family: Inter, sans-serif; font-size: 0.82rem; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase; cursor: pointer; transition: background 0.18s, color 0.18s, border-color 0.18s; width: 100%; }
.card__cta:hover { background: var(--accent); color: #fff; border-color: var(--accent); }
.card--featured .card__cta { background: var(--accent); color: #fff; border-color: var(--accent); }
.card--featured .card__cta:hover { background: var(--accent2); border-color: var(--accent2); }

.footer { border-top: 1px solid var(--border); padding: 20px 24px; text-align: center; font-size: 0.75rem; color: var(--text2); }

.toast { position: fixed; bottom: 28px; left: 50%; transform: translateX(-50%); background: var(--accent); color: #fff; font-size: 0.85rem; font-weight: 600; padding: 10px 24px; border-radius: 100px; z-index: 200; pointer-events: none; white-space: nowrap; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
.toast-enter-active { transition: opacity 0.2s ease, transform 0.2s ease; }
.toast-leave-active { transition: opacity 0.3s ease, transform 0.3s ease; }
.toast-enter-from   { opacity: 0; transform: translateX(-50%) translateY(8px); }
.toast-leave-to     { opacity: 0; transform: translateX(-50%) translateY(8px); }

@media (max-width: 860px) {
  .grid { grid-template-columns: 1fr; max-width: 460px; margin: 0 auto; }
  .main__controls { flex-direction: column; align-items: flex-start; }
}
@media (max-width: 480px) {
  .header { padding: 48px 16px 40px; }
  .mode-toggle { top: 14px; right: 14px; }
  .main { padding: 32px 16px 48px; }
  .sort-group { flex-wrap: wrap; }
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation-duration: 0.01ms !important; transition-duration: 0.01ms !important; }
}
`

const style = document.createElement('style')
style.textContent = css
document.head.appendChild(style)

createApp(App).mount('#app')
