# Cape Town Food Fest — Ticket Landing Page

**LCA Course 1 · Frontend Web Development · Exercise 02**

---

## Project Overview

A Vue 3 single-page landing that displays ticket tiers for the Cape Town Food Fest annual outdoor festival. Users can browse Bronze, Silver, and Gold ticket options, favourite tiers they're interested in, and sort by price.

**Vue concepts used:**
- Reusable `TicketCard` component with **props**, **emits**, and **named slots** (`#badge`, `#cta`)
- All ticket data stored locally in a JavaScript array — no hard-coded HTML per tier
- **Computed property** (`sortedTickets`) drives dynamic sorting
- `ref` for reactive state: favourites, dark/light mode, sort selection, toast visibility
- `v-for` renders cards from data; `v-if` conditionally renders the featured badge via slot
- **Dark / light mode toggle** (stretch goal)
- **Sort by price** ascending / descending (stretch goal)
- Hover and favourite animations (stretch goal)
- **"Buy Now" / "Notify Me"** CTA via the `#cta` slot (stretch goal)

---

## Running the Project

No build step or install required. Vue 3 loads via CDN.

**Option 1 — Open directly:**
Double-click `index.html` to open in your browser.

**Option 2 — Local server (recommended):**
```bash
# Python
python -m http.server 3000

# Node
npx serve .
```
Then visit **http://localhost:3000**

---

## File Structure

```
week9_ex02_vuejs_food_fest/
├── index.html    # HTML shell — loads Vue 3 CDN and main.js
├── main.js       # All data, components, styles, and app logic
└── README.md
```

---

## Screenshot

> _(Add a screenshot of the running app here before submitting)_
